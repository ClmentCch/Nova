NOVA 2.2.0 uses the built-in "aurora" theme (pure black background,
blue and purple accents). No external theme assets are required.
