NOVA - custom boot system for Nintendo Switch
Version 2.2.0

NOVA.bin is a real Tegra boot payload. Load it from hekate
(bootloader/payloads/NOVA.bin or the NOVA entry created by the
installer). The installer writes the same file to both locations
and validates every copy with SHA-256.

NOVA never writes BOOT0/BOOT1, the NAND, atmosphere/ or emummc/,
and never edits bootloader/hekate_ipl.ini.

For automatic startup, open AUTOMATIC BOOT in the installer. It
places this payload in SD:/payload.bin for modchip/dongle loaders
that read it at power-on, keeps the previous payload for rollback,
and verifies the result with SHA-256.
